<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General_journal extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Journal',
								'page_title' 	=> 'General Journal'
							 );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/general_journal');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Journal');
			$this->session->set_userdata('page_title', 'General Journal');
			$this->session->set_userdata('current_page', 'general_journal');
			$this->load->view('modules/general_journal');
		}
		else{
			redirect('login');
		}
	}

	public function save_journal_gj(){
		$this->load->model('journal_gj_model');
		$journal_gj_data = $this->input->post('gj');
		$err = validates(array($journal_gj_data), array());

		if (count($err)) {
			echo jcode(array(
					'success' 	=> 3,
					'err' 		=> $err
				));
		} else {
			$gjCode = isset($journal_gj_data['gj_code']) ? $journal_gj_data['gj_code']: '';
			$check_id = $this->journal_gj_model->journal_gj_exist($gjCode);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->journal_gj_model->journal_gj_add($journal_gj_data);
				echo jcode(array('success' => 1));
			}
		}
		
	}
}
