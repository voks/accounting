<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_account extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Set Up',
								'page_title' 	=> 'Master Account'
							);
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/master_account');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Set Up');
			$this->session->set_userdata('page_title', 'Master Account');
			$this->session->set_userdata('current_page', 'master_account');
			$this->load->view('modules/master_account');
		}
		else{
			redirect('login');
		}
	}

	public function save_master_account(){
		$this->load->model('master_account_model');
		$master_account_data = $this->input->post('master');
		$err = validates(array($master_account_data), array());

		if (count($err)) {
			echo jcode(array(
								'success' => 3, 
								'err' 	  => $err
							)
					);
		} else {

			$masterName = isset($master_account_data['master_name']) ? $master_account_data['master_name']: '';
			$check_id = $this->master_account_model->master_account_exist($masterName);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->master_account_model->master_account_add($master_account_data);
				echo jcode(array('success' => 1));
			}
			
		}
	}

	public function search_master(){
		$this->load->model("master_account_model");
		$account_search = $this->input->post('searchMaster');
		$data = $this->master_account_model->master_account_get($account_search['searchMaster_name'],$account_search['searchMaster_type']);
		$html = "";

		$err = validates(array($account_search), array());

		if (count($err)) {
			if ($err<1) {
				echo jcode(array(
									'success' => 3, 
									'err' 	  => $err
								)
						);
			}
			else {
				if (!$data->num_rows()) {
						echo jcode(array('success' => 2));
				}
				else{
						foreach ($data->result() as $key) {
						$html .="
									<tr>
										<td>".$key->master_name."</td>
										<td>".$key->master_add."</td>
										<td>".$key->master_contact_person."</td>
										<td>".$key->master_tel_no."</td>
									</tr>
								";
						}

						echo jcode(array('success' => 1,'response' => $html));
				}
			}
		}
	}
}
