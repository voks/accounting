<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bank_recon extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Set Up',
								'page_title' 	=> 'Bank Recon'
								);
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/bank_recon');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Set Up');
			$this->session->set_userdata('page_title', 'Bank Recon');
			$this->session->set_userdata('current_page', 'bank_recon');
			$this->load->view('modules/bank_recon');
		}
		else{
			redirect('login');
		}
	}

	public function save_bank_recon(){
		$this->load->model('bank_recon_model');
		$bank_recon_data = $this->input->post('bank');
		$err = validates(array($bank_recon_data), array());

		if (count($err)) {
			echo jcode(array(
								'success' => 3, 
								'err' 	  => $err
							)
					);
		} else {

			$bID = isset($bank_recon_data['bank_id']) ? $bank_recon_data['bank_id']: '';
			$check_id = $this->bank_recon_model->bank_recon_exist($bID);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->bank_recon_model->bank_recon_add($bank_recon_data);
				echo jcode(array('success' => 1));
			}
			
		}

	}
}
