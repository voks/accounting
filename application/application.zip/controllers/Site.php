<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

	public function index(){
		if ($this->session->userdata('islogged')) {
			switch ($this->session->userdata('current_page')) {
				case 'system_settings':
				$this->load->model("system_settings_model");
				$this->session->set_userdata('page_tab', 'Administrator');
				$this->session->set_userdata('page_title', 'System Settings');
				$this->session->set_userdata('current_page', 'system_settings');
				$page_info = array(
					'page_tab' 		=> 'Administrator',
					'page_title' 	=> 'System Settings');
				$this->load->view('parts/header',load_data($page_info));
				$this->load->view('parts/sidebar',load_data($page_info));

				$copyright = array('copyright' => $this->system_settings_model->copyrights_show()->result_array());
				$account_group = array('account_group' => $this->system_settings_model->account_group_show()->result());

				$this->load->view('modules/system_settings',array_merge($copyright,$account_group));
				$this->load->view('parts/footer');
				break;

				case 'main_account':
				$this->load->model("system_settings_model");
				$this->session->set_userdata('page_tab', 'Set Up');
				$this->session->set_userdata('page_title', 'Main Account');
				$this->session->set_userdata('current_page', 'main_account');
				
				$page_info = array(
					'page_tab' 		=> 'Set Up',
					'page_title' 	=> 'Main Account');
				$this->load->view('parts/header',load_data($page_info));
				$this->load->view('parts/sidebar',load_data($page_info));

				$account_group = array('account_group' => $this->system_settings_model->account_group_get('Assets')->result());

				$this->load->view('modules/main_account',$account_group);

				$this->load->view('parts/footer');
				break;

				case 'subsidiary_account':
				$this->load->model("system_settings_model");

				$this->session->set_userdata('page_tab', 'Set Up');
				$this->session->set_userdata('page_title', 'Subsidiary Account');
				$this->session->set_userdata('current_page', 'main_account');
				
				$page_info = array(
					'page_tab' 		=> 'Set Up',
					'page_title' 	=> 'Subsidiary Account');
				$this->load->view('parts/header',load_data($page_info));
				$this->load->view('parts/sidebar',load_data($page_info));

				$account_list = array('account_list' => $this->system_settings_model->account_group_get('Assets')->result());

				$this->load->view('modules/subsidiary_account',$account_list);

				$this->load->view('parts/footer');
				break;

				case 'user_access':
				$this->load->model('user_access_model');
				$page_info = array(
					'page_tab' 		=> 'Administrator',
					'page_title'	=> 'User Access' 
					);
				$this->load->view('parts/header',load_data($page_info));
				$this->load->view('parts/sidebar',load_data($page_info));
				$user_access_type = array('user_access_type' => $this->user_access_model->show_user_type()->result());
				$user_access = array('user_access' => $this->user_access_model->show_user_access()->result());
				$projects = array('project_list' => $this->user_access_model->project_list());
				$this->load->view('modules/user_access', array_merge($user_access,$projects,$user_access_type));
				$this->load->view('parts/footer');
				break;

				default:
				$page_info = array(
					'page_tab' 		=> $this->session->userdata('page_tab'),
					'page_title'	=> $this->session->userdata('page_title') 
					);
				$this->load->view('parts/header',load_data($page_info));
				$this->load->view('parts/sidebar',load_data($page_info));
				$this->load->view('modules/'.$this->session->userdata('current_page'));
				$this->load->view('parts/footer');
				break;
			}
		}
		else{
			redirect('login');
		}
	}

	// public function system_settings(){
	// 	if ($this->session->userdata('islogged')) {
	// 		$this->load->model("system_settings_model");
	// 		$page_info = array(
	// 								'page_tab' 		=> 'Administrator',
	// 								'page_title' 	=> 'System Settings');
	// 		$this->load->view('parts/header',load_data($page_info));
	// 		$this->load->view('parts/sidebar',load_data($page_info));
	// 		$copyright = array('copyright' => $this->system_settings_model->copyrights_show()->result_array());
	// 		$this->load->view('modules/system_settings',$copyright);
	// 		$this->load->view('parts/footer');
	// 	}
	// 	else{
	// 		redirect('login');
	// 	}
	// }

	// public function main_account(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));

	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function subsidiary_account(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function master_account(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function bank_recon(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function accounts_payable(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function check_dis(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function sales_journal(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function cash_receipts(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function general_journal(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function trial_balance(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function general_ledger(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function accounts_receivable(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function user_access(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function audit_trail(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function summary(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function aging(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function sales_expense(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function dashboard(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }

	// public function account_settings(){
	// 	$page_info = array(
	// 						'page_tab' 		=> $this->session->userdata('page_tab'),
	// 						'page_title'	=> $this->session->userdata('page_title') 
	// 					  );
	// 	$this->load->view('parts/header',load_data($page_info));
	// 	$this->load->view('parts/sidebar',load_data($page_info));
	// 	$this->load->view('modules/'.$this->session->userdata('current_page'));
	// 	$this->load->view('parts/footer');
	// }
}
