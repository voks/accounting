<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_journal extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Journal',
								'page_title' 	=> 'Sales Journal'
								 );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/sales_journal');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Journal');
			$this->session->set_userdata('page_title', 'Sales Journal');
			$this->session->set_userdata('current_page', 'sales_journal');
			$this->load->view('modules/sales_journal');
		}
		else{
			redirect('login');
		}
	}

	public function save_journal_sj(){
		$this->load->model('journal_sj_model');
		$journal_sj_data = $this->input->post('sj');
		$err = validates(array($journal_sj_data), array());

		if (count($err)) {
			echo jcode(array(
					'success' 	=> 3,
					'err' 		=> $err
				));
		} else {
			$siNo = isset($journal_sj_data['sj_si_no']) ? $journal_sj_data['sj_si_no']: '';
			$check_id = $this->journal_sj_model->journal_sj_exist($siNo);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->journal_sj_model->journal_sj_add($journal_sj_data);
				echo jcode(array('success' => 1));
			}
		}
		
	}
}
