<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subsidiary_account extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Set Up',
								'page_title'	=> 'Subsidiary Account' 
							  );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/subsidiary_account');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Set Up');
			$this->session->set_userdata('page_title', 'Subsidiary Account');
			$this->session->set_userdata('current_page', 'subsidiary_account');
			$this->load->view('modules/subsidiary_account');
		}
		else{
			redirect('login');
		}
	}


	public function save_subsidiary(){
		$this->load->model("subsidiary_account_model");
		$sub_account_data = $this->input->post('subsidiary');
		$err = validates(array($sub_account_data), array());

		if (count($err)) {
			echo jcode(array(
								'success' => 3, 
								'err' 	  => $err
							)
					);
		} else {

			$accountId = isset($sub_account_data['sub_code']) ? $sub_account_data['sub_code']: '';
			$check_id = $this->subsidiary_account_model->sub_account_exist($accountId);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->subsidiary_account_model->sub_account_add($sub_account_data);
				echo jcode(array('success' => 1));
			}
			
		}
	}


	public function show_accountCode(){
		return $this->db->get('tb_account_title');
	}

	public function search_subsidiary(){
		$this->load->model("subsidiary_account_model");
		$account_search = $this->input->post('searchAccount');
		$data = $this->subsidiary_account_model->sub_account_get($account_search['searchAccount_code'],$account_search['searchAccount_name'],$account_search['searchAccount_type']);
		$html = "";

		$err = validates(array($account_search), array());

		if (count($err)) {
			if ($err<1) {
				echo jcode(array(
									'success' => 3, 
									'err' 	  => $err
								)
						);
			}
			else {
				if (!$data->num_rows()) {
						echo jcode(array('success' => 2));
				}
				else{
						foreach ($data->result() as $key) {
						$html .="
									<tr>
										<td>".$key->account_type."</td>
										<td>".$key->sub_code."</td>
										<td>".$key->sub_name."</td>
									</tr>
								";
						}

						echo jcode(array('success' => 1,'response' => $html));
				}
			}
		} 	
	}
}
