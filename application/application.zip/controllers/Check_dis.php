<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Check_dis extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Journal',
								'page_title'	=> 'Check Disbursement' 
							  );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/check_dis');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Journal');
			$this->session->set_userdata('page_title', 'Check Disbursement');
			$this->session->set_userdata('current_page', 'check_dis');
			$this->load->view('modules/check_dis');
		}
		else{
			redirect('login');
		}
	}

	public function save_journal_cd(){
		$this->load->model('journal_cd_model');
		$journal_cd_data = $this->input->post("cd");
		$err = validates(array($journal_cd_data), array());

		if (count($err)) {
			echo jcode(array(
					'success'	=> 3,
					'err' 		=> $err
				));
		} else {
			$voucherNo = isset($journal_cd_data['cd_voucher_no']) ? $journal_cd_data['cd_voucher_no']: '';
			$check_id = $this->journal_cd_model->journal_cd_exist($voucherNo);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->journal_cd_model->journal_cd_add($journal_cd_data);
				echo jcode(array('success' => 1));
			}
		}
		

	}
}
