<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts_payable extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Journal',
								'page_title'	=> 'Accounts Payable' 
							  );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/accounts_payable');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){

		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Journal');
			$this->session->set_userdata('page_title', 'Accounts Payable');
			$this->session->set_userdata('current_page', 'accounts_payable');
			$this->load->view('modules/accounts_payable');
		}else{
			redirect('login');
		}
	}

	public function save_journal_ap(){
		$this->load->model('journal_ap_model');
		$journal_ap_data = $this->input->post('ap');
		$err = validates(array($journal_ap_data), array());

		if (count($err)) {
			echo jcode(array(
								'success' => 3, 
								'err' 	  => $err
							)
					);
		} else {

			$invNo = isset($journal_ap_data['ap_invoice_no']) ? $journal_ap_data['ap_invoice_no']: '';
			$check_id = $this->journal_ap_model->journal_ap_exist($invNo);
			
			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->journal_ap_model->journal_ap_add($journal_ap_data);
				echo jcode(array('success' => 1));
			}
			
		}
	}
}
