<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cash_receipts extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab'		=> 'Journal',
								'page_title' 	=> 'Cash Receipts' 
							);
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/cash_receipts');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Journal');
			$this->session->set_userdata('page_title', 'Cash Receipts');
			$this->session->set_userdata('current_page', 'cash_receipts');
			$this->load->view('modules/cash_receipts');
		}
		else{
			redirect('login');
		}
	}

	public function save_journal_cr(){
		$this->load->model('journal_cr_model');
		$journal_cr_data = $this->input->post('cr');
		$err = validates(array($journal_cr_data), array());

		if (count($err)) {
			echo jcode(array(
					'success' 	=> 3,
					'err' 		=> $err
				));
		} else {
			$orNo = isset($journal_cr_data['cr_or_no']) ? $journal_cr_data['cr_or_no'] : '';
			$check_id = $this->journal_cr_model->journal_cr_exist($orNo);

			if ($check_id) {
				echo jcode(array('success' => 2));
			} else {
				$this->journal_cr_model->journal_cr_add($journal_cr_data);
				echo jcode(array('success' => 1));
			}
			
		}
		
	}
}
