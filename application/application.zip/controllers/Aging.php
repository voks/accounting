<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aging extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Reports',
								'page_title'	=> 'Aging' 
							  );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/aging');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){

		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Reports');
			$this->session->set_userdata('page_title', 'Aging');
			$this->session->set_userdata('current_page', 'aging');
			$this->load->view('modules/aging');
		}else{
			redirect('login');
		}
	}


}
