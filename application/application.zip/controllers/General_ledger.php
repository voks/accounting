<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General_ledger extends CI_Controller {
	public function index(){
		if ($this->session->userdata('islogged')) {
			$page_info = array(
								'page_tab' 		=> 'Ledger',
								'page_title' 	=> 'General Ledger'
							 );
			$this->load->view('parts/header',load_data($page_info));
			$this->load->view('parts/sidebar',load_data($page_info));
			$this->load->view('modules/general_ledger');
			$this->load->view('parts/footer');
		}
		else{
			redirect('login');
		}
	}

	public function load_page(){
		if ($this->session->userdata('islogged')) {
			$this->session->set_userdata('page_tab', 'Ledger');
			$this->session->set_userdata('page_title', 'General Ledger');
			$this->session->set_userdata('current_page', 'general_ledger');
			$this->load->view('modules/general_ledger');
		}
		else{
			redirect('login');
		}
	}
}
