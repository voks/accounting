<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journal_sj_model extends CI_Model {

	public function journal_sj_exist($siNo){
		$sql = "select * from tb_journal_sj where sj_si_no = ?";
		$data = array($siNo);
		$query = $this->db->query($sql,$data);
		return $query->num_rows();
	}

	public function journal_sj_add($journal_sj_data){
		$this->db->insert('tb_journal_sj', $journal_sj_data);
		return $this->db->insert_id();
	}

}
