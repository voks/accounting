<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journal_cd_model extends CI_Model {

	public function journal_cd_exist($voucherNo){
		$sql = "select * from tb_journal_cd where cd_voucher_no = ?";
		$data = array($voucherNo);
		$query = $this->db->query($sql,$data);
		return $query->num_rows();
	}

	public function journal_cd_add($journal_cd_data){
		$this->db->insert('tb_journal_cd', $journal_cd_data);
		return $this->db->insert_id();
	}

}
