<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journal_cr_model extends CI_Model {

	public function journal_cr_exist($orNo){
		$sql = "select * from tb_journal_cr where cr_or_no = ?";
		$data = array($orNo);
		$query = $this->db->query($sql,$data);
		return $query->num_rows();
	}

	public function journal_cr_add($journal_cr_data){
		$this->db->insert('tb_journal_cr', $journal_cr_data);
		return $this->db->insert_id();
	}

}
