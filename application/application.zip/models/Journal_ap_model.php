<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journal_ap_model extends CI_Model {

	public function journal_ap_exist($invNo){
		$sql = "select * from tb_journal_ap where ap_invoice_no = ?";
		$data = array($invNo);
		$query = $this->db->query($sql,$data);
		return $query->num_rows();
	}

	public function journal_ap_add($journal_ap_data){
		$this->db->insert('tb_journal_ap', $journal_ap_data);
		return $this->db->insert_id();
	}

	public function journal_ap_trans_add(){
		$this->db->insert('tb_hournal_ap_trans', $journal_ap_trans_data);
		return $this->db->insert_id();
	}

}
