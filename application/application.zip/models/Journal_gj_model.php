<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journal_gj_model extends CI_Model {

	public function journal_gj_exist($gjCode){
		$sql = "select * from tb_journal_gj where gj_code = ?";
		$data = array($gjCode);
		$query = $this->db->query($sql,$data);
		return $query->num_rows();
	}

	public function journal_gj_add($journal_gj_data){
		$this->db->insert('tb_journal_gj', $journal_gj_data);
		return $this->db->insert_id();
	}

}
